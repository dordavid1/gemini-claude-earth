#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR/site" || exit 1

open "http://localhost:8000/" || true
python3 -m http.server 8000

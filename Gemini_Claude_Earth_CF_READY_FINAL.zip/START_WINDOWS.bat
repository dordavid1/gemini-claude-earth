@echo off
setlocal
cd /d "%~dp0site"

REM Start a tiny local web server (required for module JS + API fetches).
REM If you have Python installed, this will work.

start "" http://localhost:8000/
python -m http.server 8000

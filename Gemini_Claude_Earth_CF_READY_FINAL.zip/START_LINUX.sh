#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR/site" || exit 1

xdg-open "http://localhost:8000/" >/dev/null 2>&1 || true
python3 -m http.server 8000
